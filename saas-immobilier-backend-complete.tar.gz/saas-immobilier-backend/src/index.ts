/**
 * ENTRY POINT - Express API Server
 * 
 * SaaS Immobilier - Backend API
 * Port: 3000
 */

import "express-async-errors";
import express, { Express, Request, Response, NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import { PrismaClient } from "@prisma/client";

// Routes
import leadsRoutes from "./routes/leads.routes";
import propertiesRoutes from "./routes/properties.routes";

const app: Express = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 3000;

// ============================================================================
// MIDDLEWARE
// ============================================================================

// Security
app.use(helmet());
app.use(cors());

// Body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============================================================================
// HEALTH CHECK
// ============================================================================

app.get("/health", (req: Request, res: Response) => {
  res.json({ status: "ok", message: "Server is running" });
});

// ============================================================================
// API ROUTES
// ============================================================================

// Version v1 de l'API
const apiV1 = express.Router();

// Leads
apiV1.use("/leads", leadsRoutes);

// Properties
apiV1.use("/properties", propertiesRoutes);

// Routes collecte
app.use("/api/v1", apiV1);

// ============================================================================
// ERROR HANDLING
// ============================================================================

// 404 - Not Found
app.use((req: Request, res: Response) => {
  res.status(404).json({
    error: "Not Found",
    path: req.path,
    method: req.method,
  });
});

// Global error handler
app.use(
  (
    error: Error,
    req: Request,
    res: Response,
    next: NextFunction
  ) => {
    console.error("[Error]", error);

    res.status(500).json({
      error: "Internal Server Error",
      message:
        process.env.NODE_ENV === "development"
          ? error.message
          : "An error occurred",
    });
  }
);

// ============================================================================
// STARTUP
// ============================================================================

async function main() {
  try {
    // Test database connection
    await prisma.$executeRaw`SELECT 1`;
    console.log("✅ Database connected");

    // Start server
    app.listen(PORT, () => {
      console.log(`\n🚀 Server running on http://localhost:${PORT}`);
      console.log(`📚 API available at http://localhost:${PORT}/api/v1`);
      console.log(`🏥 Health check: http://localhost:${PORT}/health\n`);
    });
  } catch (error) {
    console.error("❌ Failed to start server:", error);
    process.exit(1);
  }
}

// Handle shutdown
process.on("SIGINT", async () => {
  console.log("\n⏹️  Shutting down gracefully...");
  await prisma.$disconnect();
  process.exit(0);
});

main();
